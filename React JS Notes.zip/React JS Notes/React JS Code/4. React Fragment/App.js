import React, { Component, Fragment } from "react";

class App extends Component {
  render() {
    return (
      // <Fragment>
      //   <h1>Hello GeekyShows</h1>
      //   <h2>Hello World</h2>
      // </Fragment>
      <>
        <h1>Hello GeekyShows</h1>
        <h2>Hello World</h2>
      </>
    );
  }
}

export default App;
