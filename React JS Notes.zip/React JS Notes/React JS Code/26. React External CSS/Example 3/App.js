import React, { Component } from "react";
import "./App.css";
export default class App extends Component {
  render() {
    return (
      <React.Fragment>
        <h1 className="txtc txts">Hello App</h1>
      </React.Fragment>
    );
  }
}
