import ReactDOM from "react-dom";
import el from "./App";

// Rendering Element
ReactDOM.render(el, document.getElementById("root"));
