import React from "react";
const MyContext = React.createContext();
// console.log(MyContext);
export const Provider = MyContext.Provider;
export const Consumer = MyContext.Consumer;
