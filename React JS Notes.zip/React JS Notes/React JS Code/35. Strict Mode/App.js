import React, { Component, StrictMode } from "react";
import User from "./User";
export default class App extends Component {
  render() {
    return (
      <StrictMode>
        <User />
      </StrictMode>
    );
  }
}
