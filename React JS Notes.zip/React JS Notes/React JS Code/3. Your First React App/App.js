import React, { Component } from "react";

class App extends Component {
  render() {
    return <h1>Hello GeekySHows walo</h1>;
  }
}

export default App;
