import React from "react";
import ReactDOM from "react-dom";
import Student from "./Student";

ReactDOM.render(<Student />, document.getElementById("root"));
