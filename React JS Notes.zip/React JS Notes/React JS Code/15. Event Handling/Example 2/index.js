import React from "react";
import ReactDOM from "react-dom";
import Student from "./Student";

// Rendering Component
ReactDOM.render(<Student name="Rahul" />, document.getElementById("root"));
