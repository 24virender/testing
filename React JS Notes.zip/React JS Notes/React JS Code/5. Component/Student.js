import React, { Component } from "react";

// Function Component
// function Student (){
//  return <h1>Hello Rahul</h1>;
// }

// Class Component
class Student extends Component {
  render() {
    return <h1>Hello Rahul</h1>;
  }
}

export default Student;
