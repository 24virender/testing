import React from "react";
import ReactDOM from "react-dom";
import App from "./App";
const arrValues = [10, 20, 30, 40];
ReactDOM.render(<App numbers={arrValues} />, document.getElementById("root"));
