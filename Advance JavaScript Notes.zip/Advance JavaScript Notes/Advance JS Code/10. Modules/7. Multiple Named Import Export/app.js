// Multiple Named Import
import { Nokia, show, a } from "./mobile.js";
const n = new Nokia();
n.VolumnUp();
show();
console.log(a);
