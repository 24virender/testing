// Default Export Variable
const a = 10;
export default a;
