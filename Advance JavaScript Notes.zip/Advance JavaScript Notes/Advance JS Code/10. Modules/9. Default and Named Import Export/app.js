// Default and Named Import
import Nokia, { show } from "./mobile.js";
const n = new Nokia();
n.VolumnUp();
show();
